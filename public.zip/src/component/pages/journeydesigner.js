import React from 'react'

const Journeydesigner = () => {
  return (
    <div>Journeydesigner</div>
  )
}

export default Journeydesigner