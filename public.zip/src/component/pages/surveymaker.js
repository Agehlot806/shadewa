import React from 'react'

const Surveymaker = () => {
  return (
    <div>Surveymaker</div>
  )
}

export default Surveymaker